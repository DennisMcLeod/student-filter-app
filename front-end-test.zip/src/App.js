import React, {useState, useEffect, useReducer} from 'react';
import './App.css';
import StudentList from './Components/StudentList'
import AppContext from './context/AppContext'
import studentDataReducer from './reducers/studentDataReducer'


// Sorry this is so late, I ended up being incredibly busy after starting the tech challenge and also decided to use this test as an opportunity to learn how to manage state in React using hooks.

function App() {
  const [filteredStudents, setFilteredStudents] = useState([])
  const [studentData, studentDataDispatch] = useReducer(studentDataReducer, [])
  const [studentFilter, setStudentFilter] = useState('')
  const [tagFilter, setTagFilter] = useState('')


  // Filter students by both first/last name and tags
  useEffect(() => {
    // TODO: Error handling for '/' in regex
    const studentFilterRegEx = studentFilter[studentFilter.length - 1] !== '\\' ? new RegExp(studentFilter, 'i') : ''
    const tagFilterRegEx = tagFilter[tagFilter.length - 1] !== '\\' ? new RegExp(tagFilter, 'i') : ''

    const filteredStudents = 
    studentData
      .filter(student => {
        return student.firstName.match(studentFilterRegEx) || student.lastName.match(studentFilterRegEx) 
      })
      .filter(student => {
        if (!tagFilter) return true
        
        if (!('tags' in student)) return false

        return student.tags.find(tag => {
          return tag.tagName.match(tagFilterRegEx)
        })



      })
      
    setFilteredStudents(filteredStudents)


  }, [tagFilter, studentFilter, studentData])

 
  // Get student data from API request and populate state
  useEffect(() => {
    const getStudentData = async () => {
      const response = await fetch(
        "https://www.hatchways.io/api/assessment/students"
      ).then(response => response.json());

      const data = await response.students

      
        console.log(data)
      studentDataDispatch({type: 'POPULATE_DATA', data})
    };

    getStudentData();
  }, []);

  return (
    <div className="App">
      <AppContext.Provider value={ {filteredStudents, studentData, studentFilter, setStudentFilter, tagFilter, setTagFilter, studentDataDispatch }}>
        <StudentList />
      </AppContext.Provider>
    </div>
  );
}

export default App;
